﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication5
{
    #region "Classes"
    public abstract class Pessoa
    {
        public Pessoa()
        {
            contactos = new List<Telefone>();
        }
        public int numero { get; set; }
        public string nome { get; set; }
        public string morada { get; set; }
        public string codigo_postal { get; set; }
        public string email { get; set; }
        //composição
        public List<Telefone> contactos { get; set; }
        public override string ToString()
        {
            return "Nome - " + this.nome + "; Email - " + this.email;
        }
    }
    public class Telefone
    {
        public string descricao { get; set; }
        public string telefone { get; set; }
    }
    public class Formacao
    {
        public string designacao { get; set; }
        public int horas { get; set; }
        public string descricao { get; set; }
    }
    #endregion

    public enum AreaFormacao
    {
        Informática,
        Línguas,
        Secretariado,
        Marketing,
        Gestão,
        Contabilidade
    }

    //herança
    public class Formador : Pessoa
    {
        public Formador()
        {
            contactos = new List<Telefone>();
            formacoes = new List<Formacao>();
        }
        public List<Formacao> formacoes { get; set; }
        public AreaFormacao Area { get; set; }
        public int AnosExperiencia { get; set; }
    }

    public class Formando : Pessoa
    {
        public Formando()
        {
            contactos = new List<Telefone>();
            inscricoes = new List<Formacao>();
        }
        public List<Formacao> inscricoes { get; set; }
    }

}
