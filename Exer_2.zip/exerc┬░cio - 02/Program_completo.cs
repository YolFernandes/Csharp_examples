﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


// ===================

    #region "Classes"
    public abstract class Pessoa
    {
        public Pessoa()
        {
            contactos = new List<Telefone>();
        }
        public int numero { get; set; }
        public string nome { get; set; }
        public string morada { get; set; }
        public string codigo_postal { get; set; }
        public string email { get; set; }
        //composição
        public List<Telefone> contactos { get; set; }
        public override string ToString()
        {
            return "Nome - " + this.nome + "; Email - " + this.email;
        }
    }
    public class Telefone
    {
        public string descricao { get; set; }
        public string telefone { get; set; }
    }
    public class Formacao
    {
        public string designacao { get; set; }
        public int horas { get; set; }
        public string descricao { get; set; }
    }
    #endregion

    public enum AreaFormacao
    {
        Informática,
        Línguas,
        Secretariado,
        Marketing,
        Gestão,
        Contabilidade
    }

    //herança
    public class Formador : Pessoa
    {
        public Formador()
        {
            contactos = new List<Telefone>();
            formacoes = new List<Formacao>();
        }
        public List<Formacao> formacoes { get; set; }
        public AreaFormacao Area { get; set; }
        public int AnosExperiencia { get; set; }
    }

    public class Formando : Pessoa
    {
        public Formando()
        {
            contactos = new List<Telefone>();
            inscricoes = new List<Formacao>();
        }
        public List<Formacao> inscricoes { get; set; }
    }

// ===================

namespace ConsoleApplication5
{
    class Program
    {
        //static List<Formador> lista_formadores = new List<Formador>();

        static void Main(string[] args)
        {
            // static List<Formador> lista_formadores = new List<Formador>();
            #region "Menu principal"
            string opcao = "";

            List<Formador> lista_formadores = new List<Formador>();

            int quantos_Lisboa = lista_formadores.Count(f => f.morada == "Lisboa");
            int anos5 = lista_formadores.Count(f => f.AnosExperiencia > 5);
            int anos2a4 = lista_formadores.Count(f => f.AnosExperiencia >= 2 && f.AnosExperiencia <= 4);

            //adicionar valores default
            Formador tmp0 = new Formador();
            tmp0.numero = 12345;
            tmp0.nome = "Ana";
            tmp0.morada = "Coimbra";
            tmp0.codigo_postal = "5432-210";
            tmp0.email = "ana@mail.pt";
            tmp0.Area = AreaFormacao.Informática;
            tmp0.AnosExperiencia = 5;
            lista_formadores.Add(tmp0);

            Formador tmp1 = new Formador();
            tmp1.numero = 12;
            tmp1.nome = "Bella";
            tmp1.morada = "Lisboa";
            tmp1.codigo_postal = "1000-000";
            tmp1.email = "bella@gmail.pt";
            tmp1.Area = AreaFormacao.Línguas;
            tmp1.AnosExperiencia = 4;
            lista_formadores.Add(tmp1);

            Formador tmp2 = new Formador();
            tmp2.numero = 3;
            tmp2.nome = "Katia";
            tmp2.morada = "Porto";
            tmp2.codigo_postal = "2000-000";
            tmp2.email = "katia@gmail.pt";
            tmp2.Area = AreaFormacao.Contabilidade;
            tmp2.AnosExperiencia = 10;
            lista_formadores.Add(tmp2);

            Formador tmp3 = new Formador();
            tmp3.numero = 3;
            tmp3.nome = "Isabel";
            tmp3.morada = "Faro";
            tmp3.codigo_postal = "2000-000";
            tmp3.email = "isabel@gmail.pt";
            tmp3.Area = AreaFormacao.Gestão;
            tmp3.AnosExperiencia = 1;
            lista_formadores.Add(tmp3);       

//   lista_formadores.Add(new Formador("Catia", "Porto", "2000-100", "catia@catia.pt", AreaFormacao.Contabilidade, 7));
            //lista_formadores.Add(new Formador(1, "Ana", "R. do Alecrim", "1000-100"));
            //lista_formadores.Add(new Formador("Ana", AreaFormacao.Informática , 4, "Lisboa"));
 
            do
            {
                Console.Clear();
                Console.WriteLine("Gestão de dados de formadores\n");
                Console.WriteLine("1  - Listar Formadores");
                Console.WriteLine("2  - Criar Formador");
                Console.WriteLine("3  - Editar Formador");
                Console.WriteLine("4  - Eliminar Formador");
                Console.WriteLine("5  - Estatisticas");
                Console.WriteLine("51 - Lista dos Formadores de Lisboa");
                Console.WriteLine("52 - Lista de Formadores com mais de 5 anos de experiencia");
                Console.WriteLine("53 - Lista de Formadores que tenham entre 2 a 4 anos de experiencia");
                Console.WriteLine("54 - Total de Formadores por Area");
                Console.WriteLine();
                Console.WriteLine("Sair? (S ou s)");
                opcao = Console.ReadLine();

                switch (opcao)
            {
                #region "listar formadores"
                case "1":
                    Console.Clear();
                    Console.WriteLine("A sua opcao foi " + opcao + " - Lista de Formadore(s)\n");
                    Console.WriteLine();
//                    Console.WriteLine("Formadores\n");
                    Console.WriteLine("Número\tNome\t\tMorada\t\tCódigo postal\tEmail\n");
                    Console.WriteLine("-----------------------------------------------");
                    foreach (Formador _f in lista_formadores)
                    {
                        Console.WriteLine("{0}\t{1}\t\t{2}\t\t{3}\t{4}\n",
                        _f.numero, _f.nome, _f.morada, _f.codigo_postal, _f.email);
                    }
                    Console.WriteLine();
                    Console.WriteLine("Pressione Return para voltar ao Menu Principal");
                    Console.ReadLine();
                    break;
                #endregion

                #region "criar formador"
                case "2":
                    Console.Clear();
                    Console.WriteLine ("A sua opcao foi "+opcao + " - Criar Formador\n");
                    Console.WriteLine();
                    Formador f = new Formador();
                    Console.WriteLine("Criar formador\n");
                    Console.Write("\tNúmero\t");
                    f.numero = int.Parse(Console.ReadLine());
                    Console.Write("\tNome\t");
                    f.nome = Console.ReadLine();
                    Console.Write("\tMorada\t");
                    f.morada = Console.ReadLine();
                    Console.Write("\tCódigo postal\t");
                    f.codigo_postal = Console.ReadLine();
                    Console.Write("\tEmail\t");
                    f.email = Console.ReadLine();
                    Console.Write("\tArea\t");
//                    f.Area = Console.ReadLine();             ?????
                    Console.Write("\tAnos de Experiencia\t");
                    f.AnosExperiencia = int.Parse(Console.ReadLine());
                    lista_formadores.Add(f);
                    Console.WriteLine();
                    Console.WriteLine("Pressione Return para voltar ao Menu Principal");
                    Console.ReadLine();
                    break;
                #endregion

                #region "editar formador"
                case "3":
                    Console.Clear();
                    Console.WriteLine ("A sua opcao foi " +opcao + " - Editar Formador\n");
                    Console.WriteLine();
//                    Console.WriteLine("Formadores\n");
                    Console.WriteLine("Número\tNome\t\tMorada\t\tCódigo postal\tEmail\n");  // alterar
                    Console.WriteLine("-----------------------------------------------");

                    foreach (Formador _f in lista_formadores)
                    {
                        Console.WriteLine("{0}\t{1}\t\t{2}\t\t{3}\t\t{4}\n",                // alterar
                        _f.numero, _f.nome, _f.morada,
                        _f.codigo_postal, _f.email);                                        // alterar
                    }
                    Console.WriteLine("\nInsira o número do formador a editar");
                    int numero_formador_editar = int.Parse(Console.ReadLine());
                    Formador formador_editar = new Formador();
                    foreach (Formador _f in lista_formadores)
                    {
                        if (_f.numero == numero_formador_editar)
                        {
                            formador_editar = _f;
                            break;
                        }
                    }
                    Console.WriteLine("\nDados do formador a editar");
                    Console.WriteLine("{0}\t{1}\t\t{2}\t\t{3}\t\t{4}\n",
                    formador_editar.numero, formador_editar.nome,
                    formador_editar.morada, formador_editar.codigo_postal,
                    formador_editar.email);
                    Console.WriteLine("\nInsira os dados do formador\n");
                    Console.Write("\tNúmero\t");
                    formador_editar.numero = int.Parse(Console.ReadLine());
                    Console.Write("\tNome\t");
                    formador_editar.nome = Console.ReadLine();
                    Console.Write("\tMorada\t");
                    formador_editar.morada = Console.ReadLine();
                    Console.Write("\tCódigo postal\t");
                    formador_editar.codigo_postal = Console.ReadLine();
                    Console.Write("\tEmail\t");
                    formador_editar.email = Console.ReadLine();
                    Console.Write("\tArea\t");
//                    f.Area = Console.ReadLine();             ?????
                    Console.Write("\tAnos de Experiencia");
                    //f.AnosExperiencia = int.Parse(Console.ReadLine()); ?????
                    Console.WriteLine();
                    Console.WriteLine("Pressione Return para voltar ao Menu Principal");
                    Console.ReadLine();
                    break;
                #endregion

                #region "eliminar formador"
                case "4":
                    Console.Clear();
                    Console.WriteLine("A sua opcao foi " + opcao + " - Eliminar Formador\n");
                    Console.WriteLine();
 //                   Console.WriteLine("Formadores\n");
                    Console.WriteLine("Número\tNome\t\tMorada\t\tCódigo postal\tEmail\n");  // alterar
                    Console.WriteLine("-----------------------------------------------");
                    foreach (Formador _f in lista_formadores)
                    {
                        Console.WriteLine("{0}\t{1}\t\t{2}\t\t{3}\t\t{4}\n",                // alterar
                        _f.numero, _f.nome, _f.morada,
                        _f.codigo_postal, _f.email);                                        // alterar
                    }
                    Console.WriteLine("\nInsira o número do formador a eliminar");
                    int numero_formador_eliminar = int.Parse(Console.ReadLine());
                    Formador formador_eliminar = new Formador();
                    foreach (Formador _f in lista_formadores)
                    {
                        if (_f.numero == numero_formador_eliminar)
                        {
                            formador_eliminar = _f;
                            break;
                        }
                        else
                        {
                            Console.WriteLine("Nao existe qualquer Formador com o numero ", numero_formador_eliminar);
                            break;
                        }
                    }
                    lista_formadores.Remove(formador_eliminar);
                    Console.WriteLine();
                    Console.WriteLine("Pressione Return para voltar ao Menu Principal");
                    Console.ReadLine();
                    break;
                #endregion

                #region "estatisticas"
                case "5":
                    Console.Clear();
                    Console.WriteLine ("A sua opcao foi "+opcao +" - Estatisticas");
                    Console.WriteLine();
 
                    var p1 = from _f in lista_formadores
                    where _f.AnosExperiencia > 5 
                    select new { _f.nome, _f.AnosExperiencia }; 

                    foreach (var _f in p1)
                    {
                        Console.WriteLine("Nome\t\tAnos de Experiencia\n");
                        Console.WriteLine("-----------------------------------");

                        Console.WriteLine(_f.nome + "\t\t" + _f.AnosExperiencia.ToString());  
                    }
//                    Console.WriteLine("------------------------------------");
//                    Console.ReadLine();   
                    //máximo 
                    int maximo = lista_formadores.Max(_f => _f.AnosExperiencia);
                    //média de anos de experiência
                    double media = lista_formadores.Average(_f => _f.AnosExperiencia);

                    Console.WriteLine("máximo  \t" + maximo.ToString());
                    Console.WriteLine("média   \t" + media.ToString("0.00"));
                    Console.WriteLine();
                    Console.WriteLine("Pressione Return para voltar ao Menu Principal");
                    Console.ReadLine();
                    break;
                #endregion

                #region "Lisboa"
                case "51":                    
                    Console.Clear();
                    Console.WriteLine("A sua opcao foi " + opcao + " - Lista de Formadore(s) com morada em Lisboa\n");
                    Console.WriteLine();

                    //Console.Write("Local?  "); 
                    //string local = Console.ReadLine();
                    //if (string.Equals(local, "Lisboa", StringComparison.OrdinalIgnoreCase)) // ????? nao está a funcionar
                    //{
                        int quantos = lista_formadores.Count(_f => _f.morada == "Lisboa");
                        Console.WriteLine("Lisboa tem "+quantos.ToString() +" Formadore(s)");
                    //}
                    //else Console.WriteLine("Escolheu um local diferente de Lisboa");
                    Console.WriteLine();
                    Console.WriteLine("Pressione Return para voltar ao Menu Principal");
                    Console.ReadLine();
                    break;
                #endregion

                #region "antiguidade > 5 anos"
                case "52":
                    Console.Clear();
                    Console.WriteLine ("A sua opcao foi "+opcao + " - Lista de Formadore(s) com mais de 5 anos de experiencia\n");
                    Console.WriteLine();
                    int quantos5 = lista_formadores.Count(_f => _f.AnosExperiencia > 5);
                    Console.WriteLine(quantos5.ToString() +"  Formadore(s) com mais de 5 anos de experiencia\n");
                    Console.WriteLine();

//                    Console.WriteLine("Formadores\n\n");
                    Console.WriteLine("Nome\tAnos de Experiencia");
                    Console.WriteLine("------------------------------------");
                    foreach (Formador _f in lista_formadores)       // como seleccionar os formadores ?????
                    {
                        Console.WriteLine("{0}\t{1}\n",
                        _f.nome, _f.AnosExperiencia);
                    }
                    Console.WriteLine();
                    Console.WriteLine("Pressione Return para voltar ao Menu Principal");
                    Console.ReadLine();
                    break;
                #endregion

                #region "antiguidade entre 2 e 4 anos"
                case "53":
                    Console.Clear();
                    Console.WriteLine("A sua opcao foi " + opcao + " - Lista de Formadore(s) que tenham entre 2 e 4 anos de experiencia\n");
                    Console.WriteLine();
                    int quantos2a4 = lista_formadores.Count(_f => _f.AnosExperiencia >= 2
                                                 && _f.AnosExperiencia <= 4);
                    Console.WriteLine(quantos2a4.ToString() +"  Formadore(s) que tenham entre 2 e 4 anos de experiencia\n");
                    Console.WriteLine();
//                    Console.WriteLine("Formadores\n\n");
                    Console.WriteLine("Nome\tAnos de Experiencia");
                    Console.WriteLine("------------------------------------");

                    foreach (Formador _f in lista_formadores)       // como seleccionar os formadores ?????
                    {
                        Console.WriteLine("{0}\t{1}\n",
                        _f.nome, _f.AnosExperiencia);
                    }
                    Console.WriteLine();
                    Console.WriteLine("Pressione Return para voltar ao Menu Principal");
                    Console.ReadLine();
                    break;
                #endregion

                #region "formadores por Area"
                case "54":
                    Console.Clear();
                    Console.WriteLine("A sua opcao foi " + opcao + " - Lista de Formadore(s) por Area\n");
 //                   Console.WriteLine();
                        // new code
                    foreach (AreaFormacao A in Enum.GetValues(typeof(AreaFormacao)).Cast<AreaFormacao>())
                    {
                        int q_area = lista_formadores.Count(_f => _f.Area == A);
                        Console.WriteLine("", A.ToString(), q_area);
                    }

                    Console.ReadLine();  
            
                    //SELECT COUNT(*) FROM TABELA?
                    Console.WriteLine("Nº de Formadores\t Areas de Formacao\n");
                    Console.WriteLine("------------------------------------");
                    foreach (AreaFormacao A in Enum.GetValues
                        (typeof(AreaFormacao)).Cast<AreaFormacao>())
                    {
                        var q1 = (from _f in lista_formadores
                                  where _f.Area == A
                                  select _f).Count();
                        Console.WriteLine("{0}\t\t\t{1}",q1, A.ToString());
                    }

                    Console.WriteLine();
                    Console.WriteLine("Pressione Return para voltar ao Menu Principal");
                    Console.ReadLine();
                    break;
                #endregion
            }
                            } while ((opcao != "S") && (opcao != "s")
                );
            #endregion //"Menu principal"
        }

        private static Formador Formador(string p)
        {
            throw new NotImplementedException();
        }
    }
}
