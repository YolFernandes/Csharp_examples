﻿namespace c_formacao
{
    partial class form_formandos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_formandos = new System.Windows.Forms.DataGridView();
            this.Nome = new System.Windows.Forms.Label();
            this.text_nome = new System.Windows.Forms.TextBox();
            this.Morada = new System.Windows.Forms.Label();
            this.text_morada = new System.Windows.Forms.TextBox();
            this.CodigoPosta = new System.Windows.Forms.Label();
            this.text_codigopostal = new System.Windows.Forms.TextBox();
            this.Localidade = new System.Windows.Forms.Label();
            this.text_localidade = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.Label();
            this.text_email = new System.Windows.Forms.TextBox();
            this.NIF = new System.Windows.Forms.Label();
            this.telefone = new System.Windows.Forms.Label();
            this.telemovel = new System.Windows.Forms.Label();
            this.text_nif = new System.Windows.Forms.TextBox();
            this.text_telefone = new System.Windows.Forms.TextBox();
            this.text_telemovel = new System.Windows.Forms.TextBox();
            this.bt_inserir = new System.Windows.Forms.Button();
            this.bt_alterar = new System.Windows.Forms.Button();
            this.bt_eliminar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_formandos)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_formandos
            // 
            this.dgv_formandos.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.dgv_formandos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_formandos.Location = new System.Drawing.Point(120, 23);
            this.dgv_formandos.Name = "dgv_formandos";
            this.dgv_formandos.Size = new System.Drawing.Size(801, 184);
            this.dgv_formandos.TabIndex = 0;
            // 
            // Nome
            // 
            this.Nome.AutoSize = true;
            this.Nome.Location = new System.Drawing.Point(62, 254);
            this.Nome.Name = "Nome";
            this.Nome.Size = new System.Drawing.Size(35, 13);
            this.Nome.TabIndex = 1;
            this.Nome.Text = "Nome";
            // 
            // text_nome
            // 
            this.text_nome.Location = new System.Drawing.Point(120, 247);
            this.text_nome.Name = "text_nome";
            this.text_nome.Size = new System.Drawing.Size(620, 20);
            this.text_nome.TabIndex = 2;
            // 
            // Morada
            // 
            this.Morada.AutoSize = true;
            this.Morada.Location = new System.Drawing.Point(54, 284);
            this.Morada.Name = "Morada";
            this.Morada.Size = new System.Drawing.Size(43, 13);
            this.Morada.TabIndex = 3;
            this.Morada.Text = "Morada";
            // 
            // text_morada
            // 
            this.text_morada.Location = new System.Drawing.Point(120, 277);
            this.text_morada.Name = "text_morada";
            this.text_morada.Size = new System.Drawing.Size(620, 20);
            this.text_morada.TabIndex = 4;
            // 
            // CodigoPosta
            // 
            this.CodigoPosta.AutoSize = true;
            this.CodigoPosta.Location = new System.Drawing.Point(25, 315);
            this.CodigoPosta.Name = "CodigoPosta";
            this.CodigoPosta.Size = new System.Drawing.Size(72, 13);
            this.CodigoPosta.TabIndex = 5;
            this.CodigoPosta.Text = "Código Postal";
            // 
            // text_codigopostal
            // 
            this.text_codigopostal.Location = new System.Drawing.Point(120, 308);
            this.text_codigopostal.Name = "text_codigopostal";
            this.text_codigopostal.Size = new System.Drawing.Size(144, 20);
            this.text_codigopostal.TabIndex = 6;
            // 
            // Localidade
            // 
            this.Localidade.AutoSize = true;
            this.Localidade.Location = new System.Drawing.Point(38, 351);
            this.Localidade.Name = "Localidade";
            this.Localidade.Size = new System.Drawing.Size(59, 13);
            this.Localidade.TabIndex = 7;
            this.Localidade.Text = "Localidade";
            // 
            // text_localidade
            // 
            this.text_localidade.Location = new System.Drawing.Point(120, 344);
            this.text_localidade.Name = "text_localidade";
            this.text_localidade.Size = new System.Drawing.Size(620, 20);
            this.text_localidade.TabIndex = 8;
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.Location = new System.Drawing.Point(65, 389);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(32, 13);
            this.Email.TabIndex = 9;
            this.Email.Text = "Email";
            // 
            // text_email
            // 
            this.text_email.Location = new System.Drawing.Point(120, 382);
            this.text_email.Name = "text_email";
            this.text_email.Size = new System.Drawing.Size(620, 20);
            this.text_email.TabIndex = 10;
            // 
            // NIF
            // 
            this.NIF.AutoSize = true;
            this.NIF.Location = new System.Drawing.Point(73, 427);
            this.NIF.Name = "NIF";
            this.NIF.Size = new System.Drawing.Size(24, 13);
            this.NIF.TabIndex = 11;
            this.NIF.Text = "NIF";
            // 
            // telefone
            // 
            this.telefone.AutoSize = true;
            this.telefone.Location = new System.Drawing.Point(48, 469);
            this.telefone.Name = "telefone";
            this.telefone.Size = new System.Drawing.Size(49, 13);
            this.telefone.TabIndex = 12;
            this.telefone.Text = "Telefone";
            // 
            // telemovel
            // 
            this.telemovel.AutoSize = true;
            this.telemovel.Location = new System.Drawing.Point(342, 469);
            this.telemovel.Name = "telemovel";
            this.telemovel.Size = new System.Drawing.Size(56, 13);
            this.telemovel.TabIndex = 13;
            this.telemovel.Text = "Telemóvel";
            // 
            // text_nif
            // 
            this.text_nif.Location = new System.Drawing.Point(120, 420);
            this.text_nif.Name = "text_nif";
            this.text_nif.Size = new System.Drawing.Size(144, 20);
            this.text_nif.TabIndex = 14;
            // 
            // text_telefone
            // 
            this.text_telefone.Location = new System.Drawing.Point(120, 462);
            this.text_telefone.Name = "text_telefone";
            this.text_telefone.Size = new System.Drawing.Size(144, 20);
            this.text_telefone.TabIndex = 15;
            // 
            // text_telemovel
            // 
            this.text_telemovel.Location = new System.Drawing.Point(421, 462);
            this.text_telemovel.Name = "text_telemovel";
            this.text_telemovel.Size = new System.Drawing.Size(144, 20);
            this.text_telemovel.TabIndex = 16;
            // 
            // bt_inserir
            // 
            this.bt_inserir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.bt_inserir.ForeColor = System.Drawing.Color.White;
            this.bt_inserir.Location = new System.Drawing.Point(773, 244);
            this.bt_inserir.Name = "bt_inserir";
            this.bt_inserir.Size = new System.Drawing.Size(148, 23);
            this.bt_inserir.TabIndex = 17;
            this.bt_inserir.Text = "inserir dados do formando";
            this.bt_inserir.UseVisualStyleBackColor = false;
            this.bt_inserir.Click += new System.EventHandler(this.bt_inserir_Click);
            // 
            // bt_alterar
            // 
            this.bt_alterar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.bt_alterar.ForeColor = System.Drawing.Color.White;
            this.bt_alterar.Location = new System.Drawing.Point(773, 305);
            this.bt_alterar.Name = "bt_alterar";
            this.bt_alterar.Size = new System.Drawing.Size(148, 23);
            this.bt_alterar.TabIndex = 18;
            this.bt_alterar.Text = "alterar dados do formando";
            this.bt_alterar.UseVisualStyleBackColor = false;
            // 
            // bt_eliminar
            // 
            this.bt_eliminar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.bt_eliminar.ForeColor = System.Drawing.Color.White;
            this.bt_eliminar.Location = new System.Drawing.Point(773, 379);
            this.bt_eliminar.Name = "bt_eliminar";
            this.bt_eliminar.Size = new System.Drawing.Size(148, 23);
            this.bt_eliminar.TabIndex = 19;
            this.bt_eliminar.Text = "eliminar dados do formando";
            this.bt_eliminar.UseVisualStyleBackColor = false;
            this.bt_eliminar.Click += new System.EventHandler(this.bt_eliminar_Click);
            // 
            // form_formandos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1030, 509);
            this.Controls.Add(this.bt_eliminar);
            this.Controls.Add(this.bt_alterar);
            this.Controls.Add(this.bt_inserir);
            this.Controls.Add(this.text_telemovel);
            this.Controls.Add(this.text_telefone);
            this.Controls.Add(this.text_nif);
            this.Controls.Add(this.telemovel);
            this.Controls.Add(this.telefone);
            this.Controls.Add(this.NIF);
            this.Controls.Add(this.text_email);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.text_localidade);
            this.Controls.Add(this.Localidade);
            this.Controls.Add(this.text_codigopostal);
            this.Controls.Add(this.CodigoPosta);
            this.Controls.Add(this.text_morada);
            this.Controls.Add(this.Morada);
            this.Controls.Add(this.text_nome);
            this.Controls.Add(this.Nome);
            this.Controls.Add(this.dgv_formandos);
            this.Name = "form_formandos";
            this.Text = "Formandos";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_formandos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_formandos;
        private System.Windows.Forms.Label Nome;
        private System.Windows.Forms.TextBox text_nome;
        private System.Windows.Forms.Label Morada;
        private System.Windows.Forms.TextBox text_morada;
        private System.Windows.Forms.Label CodigoPosta;
        private System.Windows.Forms.TextBox text_codigopostal;
        private System.Windows.Forms.Label Localidade;
        private System.Windows.Forms.TextBox text_localidade;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.TextBox text_email;
        private System.Windows.Forms.Label NIF;
        private System.Windows.Forms.Label telefone;
        private System.Windows.Forms.Label telemovel;
        private System.Windows.Forms.TextBox text_nif;
        private System.Windows.Forms.TextBox text_telefone;
        private System.Windows.Forms.TextBox text_telemovel;
        private System.Windows.Forms.Button bt_inserir;
        private System.Windows.Forms.Button bt_alterar;
        private System.Windows.Forms.Button bt_eliminar;
    }
}