﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace c_formacao
{
    public partial class form_formandos : Form
    {
        public form_formandos()
        {
            InitializeComponent();
        }

        private void form_formandos_Load(object sender, DataGridViewCellEventArgs e)
        {
            dgv_formandos.AllowUserToAddRows = false;
            dgv_formandos.AllowUserToDeleteRows = false;
            dgv_formandos.AllowUserToResizeColumns = false;
            dgv_formandos.AllowUserToResizeRows = false;
            dgv_formandos.ColumnHeadersHeightSizeMode =
                System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_formandos.MultiSelect = false;
            dgv_formandos.ReadOnly = true;
            dgv_formandos.SelectionMode =
                System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;

            //preenchimento da DataGridView
            preencher_grid_formandos();
        }

        void preencher_grid_formandos()
        {
        //configurar DataGridView de formandos
            dgv_formandos.AllowUserToAddRows = false;
            dgv_formandos.AllowUserToDeleteRows = false;
            dgv_formandos.AllowUserToResizeColumns = false;
            dgv_formandos.AllowUserToResizeRows = false;
            dgv_formandos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_formandos.MultiSelect = false;
            dgv_formandos.ReadOnly = true;
            dgv_formandos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;

            //preencher DataGridView de formandos

            bd_formacaoEntities bd = new bd_formacaoEntities();
            dgv_formandos.DataSource = bd.tb_formando.ToList();

            //formatar colunas

            dgv_formandos.Columns[0].HeaderText = "Número";
            dgv_formandos.Columns[0].Width = 50;
            dgv_formandos.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgv_formandos.Columns[1].HeaderText = "Nome";
            dgv_formandos.Columns[1].Width = 250;
            dgv_formandos.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgv_formandos.Columns[2].Visible = false;
            dgv_formandos.Columns[3].Visible = false;
            dgv_formandos.Columns[4].Visible = false;
            dgv_formandos.Columns[5].HeaderText = "Email";
            dgv_formandos.Columns[5].Width = 250;
            dgv_formandos.Columns[5].DefaultCellStyle.Alignment =
                DataGridViewContentAlignment.MiddleLeft;
        }

        public void limpar()
        {
            foreach (Control c in this.Controls)
            {
                if (c is TextBox)
                {
                    c.Text = ""; // 
                }
            }
        }

        private void bt_inserir_Click(object sender, EventArgs e)
        {
            tb_formando f = new tb_formando();

            f.nome = text_nome.Text;
            f.morada = text_morada.Text;
            f.localidade = text_localidade.Text;
            f.codigo_postal = text_codigopostal.Text;
            f.email = text_email.Text;
            f.nif = text_nif.Text;
            f.telefone = text_telefone.Text;
            f.telemovel = text_telemovel.Text;

            bd_formacaoEntities bd = new bd_formacaoEntities();

            bd.tb_formando.Add(f);
            bd.SaveChanges();
            dgv_formandos.DataSource = bd.tb_formando.ToList();

            //depois de inserido na tabela, actualizar a GridView

            preencher_grid_formandos();

            limpar();
        }

        private void dgv_formandos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            text_nome.Text = dgv_formandos.CurrentRow.Cells[1].Value.ToString();
            text_morada.Text = dgv_formandos.CurrentRow.Cells[2].Value.ToString();
            text_codigopostal.Text = dgv_formandos.CurrentRow.Cells[3].Value.ToString();
            text_localidade.Text = dgv_formandos.CurrentRow.Cells[4].Value.ToString();
            text_telefone.Text = dgv_formandos.CurrentRow.Cells[5].Value.ToString();
            text_telemovel.Text = dgv_formandos.CurrentRow.Cells[6].Value.ToString();
            text_email.Text = dgv_formandos.CurrentRow.Cells[7].Value.ToString();
            text_nif.Text = dgv_formandos.CurrentRow.Cells[8].Value.ToString();

          //verificar ordem do array

        }
        private void bt_alterar_Click(object sender, EventArgs e)
        {
            bd_formacaoEntities bd = new bd_formacaoEntities();
            var f = bd.tb_formando.Find(
                int.Parse(dgv_formandos.CurrentRow.Cells[0].Value.ToString()));

            f.nome = text_nome.Text;
            f.morada = text_morada.Text;
            f.localidade = text_localidade.Text;
            f.codigo_postal = text_codigopostal.Text;
            f.telefone = text_telefone.Text;
            f.telemovel = text_telemovel.Text;
            f.email = text_email.Text;
            f.nif = text_nif.Text;
            bd.SaveChanges();
                dgv_formandos.DataSource = bd.tb_formando.ToList();
        }

        private void bt_eliminar_Click(object sender, EventArgs e)
        {
            bd_formacaoEntities bd = new bd_formacaoEntities();

            var f = bd.tb_formando.Find(
                int.Parse(dgv_formandos.CurrentRow.Cells[0].Value.ToString()));

            bd.tb_formando.Remove(f);
            bd.SaveChanges();
            dgv_formandos.DataSource = bd.tb_formando.ToList();
        }
    }
}
