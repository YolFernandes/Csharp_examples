﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;


namespace c_formacao
{
    class formacao
    {
        class pessoa
        {
            public int id { get; set; }
            public string nome { get; set; }
            public string morada { get; set; }
            public string codigo_postal { get; set; }
            public string localidade { get; set; }
            public string email { get; set; }
            public string nif { get; set; }
        }

        //estrutura de dados

        class formando : pessoa 
        {
            public string telefone { get; set; }
            public string telemovel { get; set; }
        }

        //métodos
        class formando_metodos 
        {
            public DataTable seleccionar()
            {
                //definir ligação à BD
                SqlConnection ligacao = new SqlConnection(
                    c_formacao.Properties.Settings.Default["bd_formacao_connection"].ToString());
                string select = "SELECT * FROM tb_formandos";
                //definir DataAdapter para execução do Select
                SqlDataAdapter da = new SqlDataAdapter(
                    select, ligacao);
                //definir DataTable para Manutencao de dados
                DataTable dt = new DataTable();
                //executar select e colocar dados em memória
                da.Fill(dt);
                return dt;
            }
            public int inserir(formando f)
            {
                //1 - definir ligação à BD
                SqlConnection ligacao = new SqlConnection(
                    c_formacao.Properties.Settings.Default["bd_formacao_connection"].ToString());
                //2 - definir Command para execução do Insert
                SqlCommand comando_insert = new SqlCommand();
                comando_insert.Connection = ligacao;
                comando_insert.CommandType = CommandType.Text;
                comando_insert.CommandText = "INSERT INTO tb_formando VALUES("
                + "@nome, @morada, @codigo_postal, @localidade, @telefone, @telemovel, @email, @nif)";
                
                //3 - definir valores a inserir na tabela
                comando_insert.Parameters.AddWithValue("@nome", f.nome);
                comando_insert.Parameters.AddWithValue("@morada", f.morada);
                comando_insert.Parameters.AddWithValue("@codigo_postal", f.codigo_postal);
                comando_insert.Parameters.AddWithValue("@localidade", f.localidade);
                comando_insert.Parameters.AddWithValue("@telefone", f.telefone);
                comando_insert.Parameters.AddWithValue("@telemovel", f.telemovel);
                comando_insert.Parameters.AddWithValue("@email", f.email);
                comando_insert.Parameters.AddWithValue("@nif", f.nif);

                //4 - executar comando

                ligacao.Open();
                int res = comando_insert.ExecuteNonQuery();
                ligacao.Close();

                //5 - devolver total de linhas afectadas com a execução do comando

                return res;
              }
             
               public int alterar(formando f)
              {
               //1 - definir ligação à base de dados
               SqlConnection ligacao = new SqlConnection(
               c_formacao.Properties.Settings.
               Default["bd_formacao_connection"].ToString());

               //2 - definir comando Update
               SqlCommand comando_update = new SqlCommand();

               //3 - configurar comando
               comando_update.Connection = ligacao;
               comando_update.CommandType = CommandType.Text;
               comando_update.CommandText =
               "UPDATE tb_formando SET " +
               "nome = @nome, " +
               "morada = @morada, " +
               "codigo_postal = @codigo_postal, " +
               "localidade = @localidade, " +
               "telefone = @telefone, " +
               "telemovel = @telemovel, " +
               "email = @email, " +
               "nif = @nif " +
               "WHERE id = @numero_formando";
               comando_update.Parameters.AddWithValue("@nome", f.nome);
               comando_update.Parameters.AddWithValue("@morada", f.morada);
               comando_update.Parameters.AddWithValue("@codigo_postal", f.codigo_postal);
               comando_update.Parameters.AddWithValue("@localidade", f.localidade);
               comando_update.Parameters.AddWithValue("@telefone", f.telefone);
               comando_update.Parameters.AddWithValue("@telemovel", f.telemovel);
               comando_update.Parameters.AddWithValue("@email", f.email);
               comando_update.Parameters.AddWithValue("@nif", f.nif);
               comando_update.Parameters.AddWithValue
                  ("@numero_formando", f.id.ToString());
                   // m...
              //4 - executar
              ligacao.Open();
              int res = comando_update.ExecuteNonQuery();
              ligacao.Close();
              return res;
              }

              public int eliminar(int id_formando)
              {
              //1 - definir ligação à base de dados
              SqlConnection ligacao = new SqlConnection(
              c_formacao.Properties.Settings.
              Default["bd_formacao_connection"].ToString());

             //2 - definir comando Delete
             SqlCommand comando_delete = new SqlCommand();

             //3 - configurar comando
             comando_delete.Connection = ligacao;
             comando_delete.CommandType = CommandType.Text;
             comando_delete.CommandText =
                 "DELETE FROM tb_formando " +
                 "WHERE id = @numero_formando";
             comando_delete.Parameters.AddWithValue
                ("@numero_formando", id_formando.ToString());

            //4 - executar
            ligacao.Open();
            int res = comando_delete.ExecuteNonQuery();
            ligacao.Close();
            return res;
            }
         }
    }        
}

